package com.example.recyclerview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.AsyncHttpStack;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    String News_Url;

    private final static String[] pictureNames = {
            "Rocket in the universe",
            "A scene in London",
            "Moon over mountains",
            "A simple moon",
            "Sun and volcano",
            "A collection of mountains",
            "River between mountains",
            "Some pine trees",
            "On Small Town",
            "Volcanoes reflection"
    };
    private final static Integer[] pictureIds = {
            R.drawable.cohete_flat,
            R.drawable.london_flat,
            R.drawable.material_flat,
            R.drawable.moon_flat,
            R.drawable.mountain_flat,
            R.drawable.mountain_mo_flat,
            R.drawable.moutain_go_flat,
            R.drawable.pine_flat,
            R.drawable.towers_flat,
            R.drawable.vulcan_flat
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        News_Url = "https://newsapi.org/v2/everything?q=tesla&from=2021-07-31&sortBy=publishedAt&apiKey=f8674e2c9e88473f90a97207f8e77cc7";
        ArrayList<ImageModel> list = fetchData();


        ImagesAdapter imagesAdapter = new ImagesAdapter(list);
        RecyclerView rvImages = findViewById(R.id.rv_images);
        rvImages.setAdapter(imagesAdapter);
        rvImages.setLayoutManager(new LinearLayoutManager(
                this,
                RecyclerView.VERTICAL,
                false));

        new MainActivity.AsyncHttpTask().execute(News_Url);


    }

    private ArrayList<ImageModel> fetchData() {
        ArrayList<ImageModel> data = new ArrayList<ImageModel>();
        for(int i = 0; i< pictureIds.length; i++ ) {
            ImageModel newItem = new ImageModel(pictureNames[i], pictureIds[i]);
            data.add(newItem);
        }
        return data;
    }

    public class AsyncHttpTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... urls) {
            String result = "";
            URL url;
            HttpURLConnection urlConnection = null;

            try {
                url = new URL(urls[0]);
                urlConnection = (HttpURLConnection) url.openConnection();
                String response = streamToString(urlConnection.getInputStream());
                parseResult(response);
                return result;


            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }
    }
    String streamToString(InputStream stream) throws IOException {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(stream));
        String data;
        String result = "";

        while ((data = bufferedReader.readLine()) != null)
            result += data;
        if (null != stream)
        {
            stream.close();
        }

        return result;

    }
    private void parseResult(String result){
        JSONObject response = null;
        try {
            response = new JSONObject(result);
            JSONArray articles = response.optJSONArray("articles");

            for (int i = 0; i<articles.length(); i++)
            {
                JSONObject article = articles.optJSONObject(i);
                String title = article.optString("title");
                Log.d("Title", title);

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

