package com.example.recyclerview;

import android.content.Intent;

public class ImageModel {
    private String imageName;
    private Integer imageId;

    public ImageModel(String imageName, Integer imageId) {
        this.imageName = imageName;
        this.imageId = imageId;
    }

    public String getImageName() {
        return imageName;
    }

    public void setImageName(String imageName) {
        this.imageName = imageName;
    }

    public Integer getImageId() {
        return imageId;
    }

    public void setImageId(Integer imageId) {
        this.imageId = imageId;
    }
}
